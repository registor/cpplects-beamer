#ifndef DIAMOND_H_INCLUDED
#define DIAMOND_H_INCLUDED

#include "CPOINT.h"
#include "CShape.h"

class Diamond: public Shape
{
public:
    Diamond(float x=0, float y=0, float _r=0, unsigned long _clr=0x00FF00):Shape(x, y, _r, _clr)
    {
    }
    double GetArea()
    {
        return 2*r*r;
    }
    double GetPerimeter()
    {
        return 4*sqrt(2.0)*r;
    }
    void Draw()
    {
        setColor(clr);
        fillTriangle(p.x-r, p.y, p.x, p.y-r, p.x+r, p.y);
        fillTriangle(p.x+r, p.y, p.x, p.y+r, p.x-r, p.y);
    }
    bool IsInside(float x, float y)
    {
        float dx = x-p.x;
        float dy = y-p.y;
        if (fabs(dx-dy)<=r && fabs(dx+dy)<=r)
            return true;
        else
            return false;
    }
    void DrawFrame()
    {
        setColor(0xFF0000);
        setLineWidth(3.0);
        line(p.x-r, p.y, p.x, p.y-r);
        line(p.x, p.y-r, p.x+r, p.y);
        line(p.x+r, p.y, p.x, p.y+r);
        line(p.x, p.y+r, p.x-r, p.y);
        setLineWidth(1.0);
    }
    ~Diamond(){}
};


#endif // DIAMOND_H_INCLUDED
