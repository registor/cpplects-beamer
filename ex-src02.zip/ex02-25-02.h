// 例02-25-02：ex02-25-02.cpp
//Xinong.h
#ifndef XINONG_H_INCLUDED
#define XINONG_H_INCLUDED

namespace Xinong
{
    int year = 2011;
    char name[] = "Xinong";
    void ShowName()
    {
        cout << name << "  " <<
            year << endl;
    }
}

#endif // XINONG_H_INCLUDED
