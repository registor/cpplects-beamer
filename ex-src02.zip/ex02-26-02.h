// 例02-26-02：ex02-26-02.cpp
//Xilin.h
#ifndef XILIN_H_INCLUDED
#define XILIN_H_INCLUDED

namespace Xilin
{
    int year = 2011;
    char name[] = "Xilin";
    void ShowName()
    {
        cout << name << "  " <<
            year << endl;
    }
}

#endif // XILIN_H_INCLUDED
