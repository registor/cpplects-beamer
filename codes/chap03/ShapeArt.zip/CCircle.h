#ifndef CCIRCLE_H_INCLUDED
#define CCIRCLE_H_INCLUDED

#include "CPOINT.h"
#include "CShape.h"

class Circle: public Shape
{
public:
    Circle(float x=0, float y=0, float _r=0, unsigned long _clr=0x00FF00):Shape(x, y, _r, _clr)
    {
    }
    double GetArea()
    {
        return PI*r*r;
    }
    double GetPerimeter()
    {
        return 2*PI*r;
    }
    void Draw()
    {
        setColor(clr);
        fillCircle(p.x, p.y, r);
    }
    bool IsInside(float x, float y)
    {
        CPoint q(x, y);
        if (Distance(p, q)<=r)
            return true;
        else
            return false;
    }
    void DrawFrame()
    {
        setColor(0xFF0000);
        setLineWidth(3.0);
        circle(p.x, p.y, r);
        setLineWidth(1.0);
    }
    ~Circle(){}
};

#endif // CCIRCLE_H_INCLUDED
