#include <iostream>
#include "Matrix.h"

using namespace std;

int main()
{
    Matrix m1(2,3);

    cin >> m1;
    cout << m1;

    return 0;
}
