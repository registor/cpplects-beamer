// 例03-37：ex03-37-main.cpp
int CPoint2D::|\tikzmark{a\thepage}|num = 0;

int main()
{
    CPoint2D v0, v1;
    int num1, num2;
    num1 = |\textcolor{red}{\textbf CPoint2D::GetCounter()}|;
    num2 = |\textcolor{red}{\textbf v0.GetCounter()}|;
}
