// 例03-27：ex03-27.cpp
int main
{
    ch_stack s;
    s.init();
    ...
    s.release();|\tikzmark{releaseprotoa}|
    return 0;
}

