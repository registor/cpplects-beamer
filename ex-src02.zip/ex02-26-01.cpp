// 例02-26-01：ex02-26-01.cpp
#include <iostream>
using namespace std;
#include "Xilin.h"

int main()
{
    Xilin::ShowName();
    return 0;
}
