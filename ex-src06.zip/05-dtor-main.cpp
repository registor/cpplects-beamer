// 例05-dtor-main：ex05-dtor-main.cpp
int main()
{
    A *b = new B(10);
    delete b;
    return 0;
}
