#ifndef SERIALIZE_H_INCLUDED
#define SERIALIZE_H_INCLUDED

// 创建对象
void createData();

#endif // SERIALIZE_H_INCLUDED
