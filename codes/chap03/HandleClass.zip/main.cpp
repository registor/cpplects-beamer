#include <iostream>

#include "handle.h"

using namespace std;

int main()
{
    Handle h;
    h.initialize();
    h.read();
    h.change(10);
    h.cleanup();

    return 0;
}
