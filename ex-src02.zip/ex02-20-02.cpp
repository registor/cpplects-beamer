// 例02-20-02：ex02-20-02.cpp
extern int G;

void p1dispG(){
   G=11;
   cout<<"in p1 G="<<G<<endl;
} 
