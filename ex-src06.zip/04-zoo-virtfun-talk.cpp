// 例04-zoo-virtfun-talk.cpp
// 实现CAnimal中的虚函数Talk

virtual void CAnimal::Talk()
{
    cout << "Do nothing!" << endl;
}
