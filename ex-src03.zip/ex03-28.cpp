// 例03-28：ex03-28.cpp
int main
{
    ch_stack s;
    ...
    |\tikzmark{releaseprotob}|return 0;
}
