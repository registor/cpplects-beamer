// 例07-abstract-main.cpp

int main()
{
    CAnimal anim("God");|\large \badmark|

    anim.Show();
    anim.Talk();

    return 0;
}

