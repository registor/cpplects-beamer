// CPoint2D类的定义
#ifndef CPoint2D_H
#define CPoint2D_H
class CPoint2D
{
public:
    CPoint2D();
    CPoint2D(int x, int y);
    CPoint2D(const CPoint2D &pt);
    int getX()
    {
        return m_x;
    }
    int getY()
    {
        return m_y;
    }
    void movePoint();
private:
    int m_x;
    int m_y;
};
#endif // CPoint2D_H
