// 例02-24：ex02-24.cpp
#ifndef __MYHEADER_H
#define __MYHEADER_H
	...
#endif
