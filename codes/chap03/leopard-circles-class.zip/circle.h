#ifndef CIRCLE_H_INCLUDED
#define CIRCLE_H_INCLUDED

#include <cstdlib> // rand����
#include <string>

using namespace std;

// ����Բ�Ľṹ
class Circle
{
// ������Ա
public:
    // ���캯��
    Circle();
    Circle(double, double, double);
    Circle(unsigned char, unsigned char, unsigned char);
    Circle(double, double, double,
           unsigned char, unsigned char, unsigned char,
           double);
    // ��������
    ~Circle();

    // ���������޸���
    void setRed(unsigned char _red){red = _red;}
    void setGreen(unsigned char _green){red = _green;}
    void setBlue(unsigned char _blue){blue = _blue;}
    void setX(double _x){x = _x;}
    void setY(double _y){y = _y;}
    void setR(double _r){r = _r;}
    void setVel(double _v){vel = _v;}

    unsigned char getRed(){return red;}
    unsigned char getGreen(){return green;}
    unsigned char getBlue(){return blue;}
    double getX(){return x;}
    double getY(){return y;}
    double getR(){return r;}
    double getVel(){return vel;}

    // ��������
    // ����һ��Բ
    void Draw();
    // �ƶ�һ��Բ
    void Move(double dx = 0.0, double dy = 0.0);
    // ����һ��Բ
    void Scale(double s = 1.0);
    // �˶�ģ��
    void Simulate(double dt = 0.1);

// ���ݳ�Ա
private:
    unsigned char red;
    unsigned char green;
    unsigned char blue;
    double x;
    double y;
    double r;
    double vel;

    string *name;
};

#endif // CIRCLE_H_INCLUDED
