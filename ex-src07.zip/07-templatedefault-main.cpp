//例07-07；ex07-07.cpp
//定义模板类的对象，演示c++定义模板类对象的方法
int main()
{
    CSafeArray <>intOb;
    CSafeArray <double> doubleOb1;
    CSafeArray<double, 100> doubleOb2;
}
