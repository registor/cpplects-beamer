// CRectangle类的定义
#ifndef CRectangle_H
#define CRectangle_H

#include "point2D.h"

class CRectangle
{
public:
    CRectangle();
    CRectangle(int x, int y, int width, int height, unsigned long clr);
    CRectangle(const CPoint2D &pt, int width, int height, unsigned long clr);
    void drawObj();
    void moveObj();
private:
    CPoint2D m_bottomLeft;
    int m_width;
    int m_height;
    unsigned long m_clr;
};

#endif // CRectangle_H
