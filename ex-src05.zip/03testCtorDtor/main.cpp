#include <iostream>
#include "derived.h"

using namespace std;

int main()
{
    derived ob;
    return 0;
}
