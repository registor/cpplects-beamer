// 例03-34：ex03-34.cpp

int main()
{
    Point2D v0, v1;
    ...
    return 0;
}

