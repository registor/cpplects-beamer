// 例05-08-04：ex05-08-04.cpp

int main()
{
    derived ob;
    return 0;
}
