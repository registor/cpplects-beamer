#ifndef SQUARE_H_INCLUDED
#define SQUARE_H_INCLUDED

#include "CPOINT.h"
#include "CShape.h"

class Square: public Shape
{
public:
    Square(float x=0, float y=0, float _r=0, unsigned long _clr=0x00FF00):Shape(x, y, _r, _clr)
    {
    }
    double GetArea()
    {
        return 4*r*r;
    }
    double GetPerimeter()
    {
        return 8*r;
    }
    void Draw()
    {
        setColor(clr);
        fillRectangle(p.x-r, p.y-r, p.x+r, p.y+r);
    }
    bool IsInside(float x, float y)
    {
        if (fabs(x-p.x)<=r && fabs(y-p.y)<=r)
            return true;
        else
            return false;
    }
    void DrawFrame()
    {
        setColor(0xFF0000);
        setLineWidth(3.0);
        rectangle(p.x-r, p.y-r, p.x+r, p.y+r);
        setLineWidth(1.0);
    }
    ~Square(){}
};

#endif // SQUARE_H_INCLUDED
