// 例01-01：ex01-01.cpp
#include <iostream>
using namespace std;
int main( )
{
    char strName[32];
    cin >> strName;
    cout << "Hello, " << strName << "!" << endl;
    return 0;
}
