// 例02-25：ex02-25.cpp
#define _DEBUG
#ifdef _DEBUG
	...
#endif
