#ifndef CPOINT_H_INCLUDED
#define CPOINT_H_INCLUDED

#include <iostream>
#include <cmath>
#include <cstdio>
#include <graph2d.h>
using namespace std;
using namespace graph;

class CPoint
{
public:
    float x;
    float y;
public:
    CPoint(float _x=0, float _y=0)
    {
        x = _x;
        y = _y;
        //cout << "Constructor:" << x << "," << y << endl;
    }
    double Distance() const
    {
        return sqrt(x*x+y*y);
    }
    double Distance(CPoint q) const
    {
        return sqrt((x-q.x)*(x-q.x)+(y-q.y)*(y-q.y));
    }
    friend double Distance(CPoint p, CPoint q);
    float GetX() const
    {
        return x;
    }
    float GetY() const
    {
        return y;
    }
    void SetX(float _x)
    {
        x = _x;
    }
    void SetY(float _y)
    {
        y = _y;
    }
    void Translate(float dx, float dy)
    {
        x = x+dx;
        y = y+dy;
    }
    ~CPoint()
    {

    }
    friend class Shape;
    friend class Circle;
    friend class Square;
};

double Distance(CPoint p, CPoint q)
{
   return sqrt((p.x-q.x)*(p.x-q.x)+(p.y-q.y)*(p.y-q.y));
}

#endif // CPOINT_H_INCLUDED
