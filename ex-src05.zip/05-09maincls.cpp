// 例05-09：ex05-09.cpp

int main()
{
    derived ob;
    ob.set(10, 20);
    ob.showx();
    ob.showy();
}

