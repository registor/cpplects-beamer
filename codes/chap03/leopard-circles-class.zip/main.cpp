/*--------------------------------------------------------------------------------
* Copyright (c) 2017,西北农林科技大学信息学院计算机科学系
* All rights reserved.
*
* 文件名称：main.c
* 文件标识：见配置管理计划书
* 摘要：使用CGraph2D绘制简单图形。
*
* 当前版本：1.0
* 作者：耿楠
* 完成日期：2019年5月9日
*
* 取代版本：无
* 原作者：耿楠
* 完成日期：2019年5月9日
------------------------------------------------------------------------------------*/
#include <iostream>
#include <vector>
#include <ctime>
#include <Graph2D.h>

#include "serialize.h"
#include "g2dcallbacks.h"
#include "circle.h"

// 使用std名字空间
using namespace std;
// 使用Graph2D名字空间
using namespace graph;

// 声明一个全局空vector
vector<Circle> g_cir;

//-----------------------------------------------------
// 名称：int main(int argc, char *argv[])
// 功能：主函数，程序的入口点
// 参数：
//       [int argc] --- 命令行参数的个数
//       [char *argv[]] --- 命令行参数字符串的指针数组
// 返回：[int] --- 返回程序结束状态码
// 作者：耿楠
// 日期：2019年5月9日
//-----------------------------------------------------
int main(int argc, char *argv[])
{
    // 置随机数种子(C++建议用nullptr)
    srand((unsigned)time(nullptr));

    getData("leopard.txt");

//    int w = getWinWidth();
//    int h = getWinHeight();
//    std::cout << w << " " << h;

    // 图形系统初始化函数，注意传入回调函数地址
    initGraph(display, keyboard);

    return 0;
}
