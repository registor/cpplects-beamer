// 例02-25-01：ex02-25-01.cpp
#include <iostream>
using namespace std;
#include "Xinong.h"

int main()
{
    Xinong::ShowName();
    return 0;
}
