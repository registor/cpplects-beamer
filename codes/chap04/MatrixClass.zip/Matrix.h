#ifndef MATRIX_H
#define MATRIX_H

#include<iostream>
#include <fstream>
#include <cmath>

using namespace std;

/*
类的定义
*/

class Matrix
{
private:
    unsigned  row, col, size;
    double *pmm;//数组指针
public:
    Matrix(unsigned r, unsigned c) : row(r), col(c) //非方阵构造
    {
        size = r * c;
        if (size > 0)
        {
            pmm = new double[size];
            for (unsigned j = 0; j < size; j++) //init
            {
                pmm[j] = 0.0;
            }
        }
        else
            pmm = NULL;
    };
    Matrix(unsigned r, unsigned c, double val ) : row(r), col(c) // 赋初值val
    {
        size = r * c;
        if (size > 0)
        {
            pmm = new double[size];
            for (unsigned j = 0; j < size; j++) //init
            {
                pmm[j] = val;
            }
        }
        else
            pmm = NULL;
    };
    Matrix(unsigned n) : row(n), col(n) //方阵构造
    {
        size = n * n;
        if (size > 0)
        {
            pmm = new double[size];
            for (unsigned j = 0; j < size; j++) //init
            {
                pmm[j] = 0.0;
            }
        }
        else
            pmm = NULL;
    };
    Matrix(const Matrix &rhs)//拷贝构造
    {
        row = rhs.row;
        col = rhs.col;
        size = rhs.size;
        pmm = new double[size];
        for (unsigned i = 0; i < size; i++)
            pmm[i] = rhs.pmm[i];
    }

    ~Matrix()//析构
    {
        if (pmm != NULL)
        {
            delete[]pmm;
            pmm = NULL;
        }
    }

    Matrix  &operator=(const Matrix&);  //如果类成员有指针必须重写赋值运算符，必须是成员

    // 流入流出操作
    friend istream &operator>>(istream&, Matrix&);
    friend ostream &operator<<(ostream&, Matrix&);          // 输出到屏幕
    friend ofstream &operator<<(ofstream &out, Matrix &obj);  // 输出到文件

    // 成员函数重载
    Matrix  operator+(const Matrix&);
    Matrix  operator-(const Matrix&);

    // 友元函数重载
    friend Matrix  operator*(const Matrix&, const Matrix&);  //矩阵乘法
    friend Matrix  operator*(double, const Matrix&);  //矩阵乘法
    friend Matrix  operator*(const Matrix&, double);  //矩阵乘法
    friend Matrix  operator/(const Matrix&, double);  //矩阵 除以单数

    // 成员重载[]运算符
    double* operator[](int i)
    {
        return pmm + i * col;
    }

    // 其他操作成员函数
    Matrix getRowVec(size_t index); // 返回第index 行的行向量,索引从0 算起
    Matrix getColVec(size_t index); // 返回第index 列的列向量,索引从0 算起
    Matrix multi(const Matrix&); // 对应元素相乘
    Matrix mtanh(); // 对应元素相乘

    Matrix cov(bool flag = true);   //协方差阵 或者样本方差
    double det();   //行列式
    Matrix solveAb(Matrix &obj);  // 克莱姆法则(Cramer's Rule)求解线性方程组
    Matrix diag();  //返回对角线元素
    Matrix T()const;   //转置
    void sort(bool); //true为从小到大
    Matrix adjoint(); // 求矩阵共轭矩阵
    Matrix inverse(); // 求矩阵的逆矩阵
    void QR(Matrix&, Matrix&)const; // 矩阵的Q、R分解
    Matrix eig_val(unsigned _iters = 1000); // 计算特征值
    Matrix eig_vect(unsigned _iters = 1000); // 计算特征向量

    double norm1();//1范数
    double norm2();//2范数
    double mean();// 矩阵均值

    void zeromean(bool flag = true);// 零均值化(zero-mean)/中心化，默认参数为true计算列
    void normalize(bool flag = true); // // 矩阵归一化，默认参数为true计算列
    Matrix exponent(double x);//每个元素x次幂
    Matrix  eye();//对角阵
    void  maxlimit(double max, double set = 0); // 将大于max的元素置为se

    // 访问器函数
    unsigned int getRow()const
    {
        return row;
    }
    unsigned int getCol()const
    {
        return col;
    }
};

#endif // MATRIX_H
