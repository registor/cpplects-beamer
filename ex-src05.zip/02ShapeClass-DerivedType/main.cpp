#include <Graph2D.h>
#include "Shape.h"
#include "Ellipse.h"
#include "Donet.h"

int main(int argc, char *argv[])
{
    CEllipse myEllip;

    //ULONG color1 = myEllip.textColor;
    CPoint2D pos = myEllip.wPos;
    ULONG color2 = myEllip.objColor;
    return 0;
}
