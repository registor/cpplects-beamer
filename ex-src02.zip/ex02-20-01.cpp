// 例02-20-01：ex02-20-01.cpp
extern void p1dispG();
static int G=0;

int main() {
   p1dispG();
   cout<<"in p G="<<G<<endl;
   return 0;
} 
