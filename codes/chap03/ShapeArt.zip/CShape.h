#ifndef CSHAPE_H_INCLUDED
#define CSHAPE_H_INCLUDED

#include "CPOINT.h"

class Shape
{
protected:
    CPoint p;
    unsigned long clr;
    float r;
    float vel;
public:
    Shape(float x=0, float y=0, float _r=0, unsigned long _clr=0x00FF00):p(x, y)
    {
        r = _r;
        clr = _clr;
        vel = 0;
    }
    void Print()
    {
        cout << p.x << "," << p.y << "," << r << endl;
    }
    void Translate(float dx, float dy)
    {
        p.Translate(dx, dy);
    }
    void Scale(float s)
    {
        r = s*r;
    }
    void Set(float x, float y, float _r, unsigned long _clr)
    {
        p.x = x;
        p.y = y;
        r = _r;
        clr = _clr;
    }
    void Get(float &x, float &y, float &_r, unsigned long &_clr)
    {
        x = p.x;
        y = p.y;
        _r = r;
        _clr = clr;
    }
    void Simulate(double dt=0.1)
    {
        double g = 9.8;

        p.y = p.y + vel*dt;
        vel = vel - g*dt;
        if (p.y<r)
            vel = -(0.6+0.3*rand()/(float)RAND_MAX)*vel;
    }
    virtual void Draw() = 0;
    virtual void DrawFrame() = 0;
    virtual bool IsInside(float x, float y) = 0;
    virtual double GetPerimeter() = 0;
    virtual double GetArea() = 0;
    virtual ~Shape() {};
};

#endif // CSHAPE_H_INCLUDED
