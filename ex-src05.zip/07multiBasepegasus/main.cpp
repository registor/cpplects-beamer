#include "Animal.h"
#include "Horse.h"
#include "Bird.h"
#include "Pegasus.h"

int main()
{
    CPegasus pegObj("Eagle", 5, 100, 2, 500);
    return 0;
}
