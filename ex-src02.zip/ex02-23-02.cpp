// 例02-23-02：ex02-23-02.cpp
#ifdef __cplusplus
    #include <iostream>
#else
    #include <stdio.h>
#endif
