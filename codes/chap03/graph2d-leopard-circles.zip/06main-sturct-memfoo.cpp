/*--------------------------------------------------------------------------------
* Copyright (c) 2017,西北农林科技大学信息学院计算机科学系
* All rights reserved.
*
* 文件名称：main.c
* 文件标识：见配置管理计划书
* 摘要：使用CGraph2D绘制简单图形。
*
* 当前版本：1.0
* 作者：耿楠
* 完成日期：2019年5月9日
*
* 取代版本：无
* 原作者：耿楠
* 完成日期：2019年5月9日
------------------------------------------------------------------------------------*/
#include<iostream>
#include<fstream>
#include <ctime>

#include <Graph2D.h>

// 使用std名字空间
using namespace std;
// 使用Graph2D名字空间
using namespace graph;

// 定义圆的结构
struct Circle
{
    // 数据成员
    unsigned char red;
    unsigned char green;
    unsigned char blue;
    double x;
    double y;
    double r;

    // 函数成员
    void Set(double _x, double _y, double _r,
             unsigned char _red = rand() % 256,
             unsigned char _green = rand() % 256,
             unsigned char _blue = rand() % 256);// 设置数据
    void Draw(); // 绘制一个圆

    // 移动一个圆
    void Move(double dx, double dy)
    {
        x = x + dx;
        y = y + dy;
    }

    // 缩放一个圆
    void Scale(double s)
    {
        r = r * s;
    }

    // 计算面积
    void GetArea()
    {
        // 设置输出精度为2位小数
        cout.precision(2);
        cout << PI * r * r << endl;
    }
};

// Graph2D回调函数原型
void display(); // 图形窗口绘制与更新函数回调函数
void keyboard(unsigned char key); // 键盘响应函数

// 全局变量
int g_n = 0;
Circle *g_cir = NULL;

//-----------------------------------------------------------------------------------------------
// 名称：int main(int argc, char *argv[])
// 功能：主函数，程序的入口点
// 参数：
//       [int argc] --- 命令行参数的个数
//       [char *argv[]] --- 命令行参数字符串的指针数组
// 返回：[int] --- 返回程序结束状态码
// 作者：耿楠
// 日期：2019年5月9日
//-----------------------------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    // 置随机数种子
    srand((unsigned)time(NULL));

    // 定义输入文件流对象并打开文件
    ifstream in("leopard.txt");

    double x, y, rad;
    unsigned int r, g, b;

    // 读入圆数据总数
    in >> g_n;

    // 申请数据空间
    g_cir = new Circle[g_n];
    // cout << g_n;
    for(int i = 0; i < g_n; i++)
    {
        // 公有时，可以直接操作数据成员
        // in >> g_cir[i].x >> g_cir[i].y >> g_cir[i].r;

        // 无法直接从文本文件中读入unsigned char数据
        // in >> r >> g >> b;
        // g_cir[i].red  = r;
        // g_cir[i].green = g;
        // g_cir[i].blue = b;

        // 建议数据成员设置为私有，然后通过公有接口进行操作
        in >> x >> y >> rad >> r >> g >> b;
        // 使用读入的颜色数据
        g_cir[i].Set(x, y, rad, r, g, b);
        // 使用默认颜色(随机产生)
        // g_cir[i].Set(x, y, rad);
    }

    // 图形系统初始化函数，注意传入回调函数地址
    initGraph(display, keyboard);

    // 清理
    in.close();
    delete []g_cir;

    return 0;
}

//-----------------------------------------------------------------------------------------------
// 名称：void Circle::Set(double _x, double _y, double _r,
//                unsigned char _red,
//                unsigned char _green,
//                unsigned char _blue)
// 功能：设置圆的参数
// 参数：
//       [double _x] --- 圆心x坐标
//       [double _y] --- 圆心y坐标
//       [double _r] --- 圆的半径
//       [unsigned char _red] --- 圆的颜色的红色分量
//       [unsigned char _green] --- 圆的颜色的绿色分量
//       [unsigned char _blue] --- 圆的颜色的蓝色分量
// 返回：无
// 作者：耿楠
// 日期：2019年5月9日
//-----------------------------------------------------------------------------------------------
void Circle::Set(double _x, double _y, double _r,
                 unsigned char _red,
                 unsigned char _green,
                 unsigned char _blue)
{
    x = _x;
    y = _y;
    r = _r;
    red = _red;
    green = _green;
    blue = _blue;
}

//-----------------------------------------------------------------------------------------------
// 名称：void Circle::Draw()
// 功能：绘制一个圆
// 参数：
//       无
// 返回：无
// 作者：耿楠
// 日期：2019年5月9日
//-----------------------------------------------------------------------------------------------
void Circle::Draw()
{
    setColor(red, green, blue);
    fillCircle(x, y, r);
}

//-----------------------------------------------------------------------------------------------
// 名称：void display()
// 功能：图形窗口绘制与更新函数回调函数
// 参数：
//       无
// 返回：无
// 作者：耿楠
// 日期：2019年5月9日
//-----------------------------------------------------------------------------------------------
void display()
{
    for(int i = 0; i < g_n; i++)
        g_cir[i].Draw();
}

//-----------------------------------------------------------------------------------------------
// 名称：void keyboard(unsigned char key)
// 功能：键盘响应函数
// 参数：
//       [unsigned char key] --- 按键的键值
// 返回：无
// 作者：耿楠
// 日期：2019年5月9日
//-----------------------------------------------------------------------------------------------
void keyboard(unsigned char key)
{
    switch(key)
    {
    case 'w':
        for(int i = 0; i < g_n; i++)
            g_cir[i].Move(0, 5);
        break;
    case 's':
        for(int i = 0; i < g_n; i++)
            g_cir[i].Move(0, -5);
        break;
    case 'a':
        for(int i = 0; i < g_n; i++)
            g_cir[i].Move(-5, 0);
        break;
    case 'd':
        for(int i = 0; i < g_n; i++)
            g_cir[i].Move(5, 0);
        break;
    case 'z':
        for(int i = 0; i < g_n; i++)
            g_cir[i].Scale(1.05);
        break;
    case 'x':
        for(int i = 0; i < g_n; i++)
            g_cir[i].Scale(0.95);
        break;
    }
}
