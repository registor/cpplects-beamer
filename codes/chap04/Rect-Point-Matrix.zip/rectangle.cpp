// CRectangle类的实现
#include <Graph2D.h>
#include "rectangle.h"

using namespace graph;

// 默认构造函数
CRectangle::CRectangle(): m_bottomLeft(0, 0)
{
    m_width = 0;
    m_height = 0;
    m_clr = RED;
}
// 带参构造函数
CRectangle::CRectangle(int x, int y, int width, int height, unsigned long clr):
    m_bottomLeft(x, y), m_width(width), m_height(height), m_clr(clr)
{
}
// 带参构造函数
CRectangle::CRectangle(const CPoint2D &pt, int width, int height, unsigned long clr):
    m_bottomLeft(pt), m_width(width), m_height(height), m_clr(clr)
{
}
void CRectangle::drawObj()
{
    setColor(m_clr);
    fillRectangle(m_bottomLeft.getX(), m_bottomLeft.getY(),
                  m_bottomLeft.getX() + m_width,
                  m_bottomLeft.getY() + m_height);
}
void CRectangle::moveObj()
{
    m_bottomLeft.movePoint();
}
