#include "CCircle.h"
#include "CDiamond.h"
#include "CSquare.h"
#include <typeinfo>
#include <fstream>
#include <vector>

using namespace std;

vector <Shape *> g_vshape;

int g_n = 0;
int g_nSelected = -1;
bool g_bStartAnim = false;

void mousePress(int message, int x, int y);
void keyboard(unsigned char key);
void display();
void displayInfo();
void loadCircles(const char *fileName);
void saveCircles(const char *fileName);

int main()
{
    loadCircles("leopard.txt");
    initGraph(display, keyboard, mousePress);

    return 0;
}

void loadCircles(const char *fileName)
{
    ifstream inFile(fileName);
    float x, y, r;
    unsigned long clr;
    string stype;

    if (!inFile) return;

    inFile >> g_n;
    cout <<g_n <<endl;

    for(int i=0; i<g_n; i++)
    {
        inFile >> stype >> x >> y >> r >> clr;
        if (stype=="Circle")
            g_vshape.push_back(new Circle(x, y, r, clr));
        else if (stype=="Square")
            g_vshape.push_back(new Square(x, y, r, clr));
        else if (stype=="Diamond")
            g_vshape.push_back(new Diamond(x, y, r, clr));
        else
            cout << "Shape error at position " << i << endl;
    }

    inFile.close();
}

void saveCircles(const char *fileName)
{
    ofstream outFile(fileName);
    float x, y, r;
    unsigned long clr;
    string stype;

    if (!outFile) return;

    outFile <<g_n <<endl;

    for(int i=0; i<g_n; i++)
    {
        g_vshape[i]->Get(x, y, r, clr);
        if (typeid(*g_vshape[i]) == typeid(Circle))
            stype = "Circle";
        else if (typeid(*g_vshape[i]) == typeid(Square))
            stype = "Square";
        else if (typeid(*g_vshape[i]) == typeid(Diamond))
            stype = "Diamond";
        else ;
        outFile << stype << "\t" << x << "\t" << y << "\t" << r << "\t" << clr << endl;
    }

    outFile.close();
}

void drawInfo()
{
    int h = getWinHeight();
    setColor(32, 64, 255);
    putText(15, h-20, "Press space key to start/stop animation");
    putText(15, h-40, "Press 'p' key to save shapes");
    putText(15, h-60, "Press key 'w', 's', 'a', 'd', 'z', 'x' to adjust shapes");
    putText(15, h-80, "Use mouse to select a shape");
}

void display()
{
    if(g_bStartAnim)
    {
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Simulate();
    }

    for(int i=0; i<g_n; i++)
        g_vshape[i]->Draw();

    if (g_nSelected!=-1)
        g_vshape[g_nSelected]->DrawFrame();

    drawInfo();
}

void keyboard(unsigned char key)
{
    switch (key)
    {
    case ' ':
        g_bStartAnim = !g_bStartAnim;
        break;
    case 'w':
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Translate(0, 5);
        break;
    case 's':
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Translate(0, -5);
        break;
    case 'a':
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Translate(-5, 0);
        break;
    case 'd':
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Translate(5, 0);
        break;
    case 'z':
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Scale(1.05);
        break;
    case 'x':
        for(int i=0; i<g_n; i++)
            g_vshape[i]->Scale(0.95);
        break;
    case 'p':
        saveCircles("modified.txt");
        break;
    case 'r':
        for (int i=0; i<g_n; i++)
        {
            delete g_vshape[i];
            g_vshape[i] = NULL;
        }
        g_vshape.clear();
        loadCircles("leopard.txt");
        g_bStartAnim = false;
    }
}

void mousePress(int message, int x, int y)
{
    if (message==LEFT_BUTTON_DOWN)
    {
        g_nSelected = -1;
        for(int i=0; i<g_n; i++)
            if (g_vshape[i]->IsInside(x, y))
                g_nSelected = i;
    }
}

