// 例02-08：ex02-08.cpp
void SetNetCamera (char *UserName = "guest", char *Password = "321",
                   char *URL = "219.145.198.100", char *ServerName = "654",
                   float Zoom = 0.2, float Alpha = 10.0, float Beta = 15.0)
{
    cout << UserName << " ";
    cout << Password << " ";
    cout << URL << " ";
    cout << ServerName << " ";
    cout << Zoom << " ";
    cout << Alpha << " ";
    cout << Beta << endl;
}
